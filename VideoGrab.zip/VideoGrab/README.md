# VideoGrab (بدون إعلانات)
1. ثبّت Android Studio (أحدث إصدار).
2. File > Open > اختر مجلد VideoGrab، وانتظر Gradle Sync (يحتاج إنترنت).
3. وصّل جوالك (USB debugging) أو شغّل محاكي، واضغط Run.
4. لإخراج APK: Build > Build APK(s).
الملفات المحمّلة تُحفظ في: Android/data/com.example.videograb/files/Movies/VideoGrab
