package com.example.videograb

import android.app.Application
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DownloadItem(val title: String, val quality: String) {
    var progress by mutableFloatStateOf(0f)
    var status by mutableStateOf("جارٍ التحميل…")
}

class MainVM(app: Application) : AndroidViewModel(app) {
    var url by mutableStateOf("")
    var loading by mutableStateOf(false)
    var ready by mutableStateOf(false)
    var info by mutableStateOf<VideoInfoUi?>(null)
    var error by mutableStateOf<String?>(null)
    val downloads = mutableStateListOf<DownloadItem>()

    init {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { Downloader.init(getApplication()) }
                ready = true
            } catch (e: Exception) {
                error = "تعذّر تجهيز المحرّك: ${e.message}"
            }
        }
    }

    fun fetch() {
        if (url.isBlank() || !ready) return
        loading = true; error = null; info = null
        viewModelScope.launch {
            try { info = Downloader.fetchInfo(url.trim()) }
            catch (e: Exception) { error = "تعذّر جلب الفيديو: ${e.message}" }
            loading = false
        }
    }

    fun start(opt: QualityOption) {
        val i = info ?: return
        val item = DownloadItem(i.title, opt.label)
        downloads.add(0, item)
        val u = url.trim()
        viewModelScope.launch {
            try {
                Downloader.download(getApplication(), u, opt.selector) { item.progress = it / 100f }
                item.progress = 1f; item.status = "تم التحميل ✓"
            } catch (e: Exception) {
                item.status = "فشل: ${e.message}"
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT) else null
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFFE53935))) {
                val vm: MainVM = viewModel()
                LaunchedEffect(shared) { if (shared != null) { vm.url = shared; } }
                AppRoot(vm)
            }
        }
    }
}

@Composable
fun AppRoot(vm: MainVM) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(tab == 1, { tab = 1 },
                    icon = { Icon(Icons.Default.Download, null) }, label = { Text("التحميلات") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) HomeScreen(vm) else DownloadsScreen(vm)
        }
    }
}

@Composable
fun HomeScreen(vm: MainVM) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(
                value = vm.url, onValueChange = { vm.url = it },
                label = { Text("الصق رابط الفيديو") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = { vm.fetch() },
                enabled = vm.ready && !vm.loading,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (!vm.ready) "جارٍ تجهيز المحرّك…" else "بحث") }
        }
        if (vm.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
        vm.info?.let { info ->
            item {
                AsyncImage(
                    model = info.thumbnail, contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(12.dp))
                )
            }
            item { Text(info.title, style = MaterialTheme.typography.titleMedium) }
            items(info.options) { opt ->
                OutlinedButton(onClick = { vm.start(opt) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text("تحميل ${opt.label}")
                }
            }
        }
    }
}

@Composable
fun DownloadsScreen(vm: MainVM) {
    if (vm.downloads.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("لا توجد تحميلات بعد") }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(vm.downloads) { d ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(d.title, maxLines = 2, style = MaterialTheme.typography.titleSmall)
                    Text("${d.quality} • ${d.status}", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { d.progress }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
