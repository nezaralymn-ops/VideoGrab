package com.example.videograb

import android.content.Context
import android.os.Environment
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class QualityOption(val label: String, val selector: String)
data class VideoInfoUi(val title: String, val thumbnail: String?, val options: List<QualityOption>)

object Downloader {

    fun init(context: Context) {
        YoutubeDL.getInstance().init(context)
        FFmpeg.getInstance().init(context)
    }

    /** يجلب عنوان الفيديو والجودات المتاحة */
    suspend fun fetchInfo(url: String): VideoInfoUi = withContext(Dispatchers.IO) {
        val info = YoutubeDL.getInstance().getInfo(url)
        val heights = info.formats.orEmpty()
            .map { it.height }
            .filter { it > 0 }
            .distinct()
            .sortedDescending()

        val options = heights.map { h ->
            QualityOption("${h}p", "bv*[height<=$h]+ba/b[height<=$h]")
        }.ifEmpty { listOf(QualityOption("أفضل جودة", "bv*+ba/b")) }

        VideoInfoUi(info.title ?: "فيديو", info.thumbnail, options)
    }

    /** يحمّل الفيديو بالجودة المختارة ويدمج الصوت والصورة في mp4 */
    suspend fun download(
        context: Context,
        url: String,
        selector: String,
        onProgress: (Float) -> Unit
    ) = withContext(Dispatchers.IO) {
        val dir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "VideoGrab"
        ).apply { mkdirs() }

        val request = YoutubeDLRequest(url).apply {
            addOption("-f", selector)
            addOption("--merge-output-format", "mp4")
            addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
        }
        YoutubeDL.getInstance().execute(request) { progress, _, _ -> onProgress(progress) }
        Unit
    }
}
